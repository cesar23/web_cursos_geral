##

descarga 

fuente: https://storage.googleapis.com/downloads.webmproject.org/releases/webp/libwebp-0.4.1-windows-x64.zip

documentacion :https://developers.google.com/speed/webp/docs/cwebp


Comandos en  cmd

```
-o  output
-q calidad (por defecto es 75)
```


```cmd
> cwebp imagen/2020-11-05_13h17_43.png -o imagen/2020-11-05_13h17_43.webp

## -q  la  calidad que va entre 1-100
> cwebp -q 50 -lossless picture.png -o picture_lossless.webp

```


#convertiremos  nuestro py a exe

```
libreria a usar 
https://pypi.org/project/auto-py-to-exe/
```
uso de :

![](https://i.imgur.com/TaL5f9z.png) 


- una vez  compilado guardamos el resultado en la  carpeta `exe`

- luego de eso modificar el archivo `start_menuContextual.reg` para que al poner el menu contextual podamos convertir cualquier  imagen
```
Windows Registry Editor Version 5.00
; Open files
[HKEY_CLASSES_ROOT\*\shell\cesarScriptPython]
@="Convertir Imagen a Webp"
"Icon"="\"D:\\repos\\curso_python\\Utilidades\\convertir Imagen a Webp\\assets\\webp-logo.ico\",0"
[HKEY_CLASSES_ROOT\*\shell\cesarScriptPython\command]
@="\"D:\\repos\\curso_python\\Utilidades\\convertir Imagen a Webp\\exe\\cwebp_file.exe\" \"%1\""

```